<?php
session_start();
require_once dirname(dirname(__FILE__))."\\app\\init.php";
$app = new App();
?>