function elementOnClick(tr) {
    window.document.location = $(tr).attr("href");
}