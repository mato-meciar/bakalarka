<?php

class Welcome extends ViewController {
    public function __construct() {
        
    }
    
    public function index() {
        $this->View(array());
    }
}
