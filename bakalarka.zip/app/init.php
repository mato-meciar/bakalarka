<?php

require_once dirname(__FILE__)."\\config.php";
require_once dirname(__FILE__)."\\core\\APP.php";
require_once dirname(__FILE__)."\\core\\BaseController.php";
require_once dirname(__FILE__)."\\core\\ViewController.php";
