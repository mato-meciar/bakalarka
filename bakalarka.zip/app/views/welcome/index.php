<h2>Vitajte na stranke TIS!</h2>
Pokracujte <a class="btn btn-default" href="<?= URL_BASE?>/public/login" role="button">prihlasenim</a>