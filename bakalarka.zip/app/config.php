<?php

define('URL_BASE', 'http://' . $_SERVER['SERVER_NAME'] . '/bakalarka');
//define('URL_BASE', 'http://localhost/');
define('CURRENT_SCHOOL_YEAR', '2016');

// MySQL
define('MYSQL_NAME', 'projekty');
define('MYSQL_USER', 'root');
define('MYSQL_PASSWORD', '');
define('MYSQL_HOST', 'localhost');
